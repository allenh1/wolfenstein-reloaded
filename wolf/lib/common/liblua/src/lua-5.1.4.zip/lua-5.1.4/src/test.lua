-- Test 1234567890
a=7
b=5
c=0
d="/usr/local"
